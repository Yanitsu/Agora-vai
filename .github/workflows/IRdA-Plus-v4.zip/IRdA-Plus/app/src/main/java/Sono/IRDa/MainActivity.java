package Sono.IRDa;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import java.io.InputStream;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import Sono.IRDa.core.Key;
import Sono.IRDa.core.Macro;
import Sono.IRDa.core.MacroEngine;
import Sono.IRDa.core.MacroParser;

public class MainActivity extends Activity {
    private PadController pad;
    private Prefs prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private TextView statusText, macroStatus, txtThr, txtDz;
    private View statusDot;
    private Button btnConnect;
    private EditText ipEdit;
    private PadView padView;
    private LinearLayout bindingsBox, axesBox, macrosBox;
    private TextView macroEmpty;
    private final List<TextView> macroTitles = new ArrayList<>();
    private List<Macro> macros = new ArrayList<>();
    private View powerOverlay;
    private boolean keepOn;

    // ---------- idioma ----------
    @Override protected void attachBaseContext(Context base) {
        String lang = Prefs.language(base);
        if (lang != null && !lang.isEmpty()) {
            Locale l = new Locale(lang);
            Locale.setDefault(l);
            Configuration cfg = new Configuration(base.getResources().getConfiguration());
            cfg.setLocale(l);
            base = base.createConfigurationContext(cfg);
        }
        super.attachBaseContext(base);
    }

    // ---------- ciclo de vida ----------
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        pad = IrdaApp.pad(this);
        prefs = pad.prefs;
        int ai = Math.max(0, Math.min(prefs.accent(), UiText.ACCENT_STYLES.length - 1));
        if (ai > 0) getTheme().applyStyle(UiText.ACCENT_STYLES[ai], true);
        getWindow().setStatusBarColor(UiText.attr(this, R.attr.accentDark));
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.status_text);
        statusDot = findViewById(R.id.status_dot);
        btnConnect = findViewById(R.id.btn_connect);
        ipEdit = findViewById(R.id.ip_edit);
        padView = findViewById(R.id.pad_view);
        macroStatus = findViewById(R.id.macro_status);
        bindingsBox = findViewById(R.id.bindings_box);
        axesBox = findViewById(R.id.axes_box);
        macrosBox = findViewById(R.id.macros_box);
        macroEmpty = findViewById(R.id.macro_empty);
        txtThr = findViewById(R.id.txt_thr);
        txtDz = findViewById(R.id.txt_dz);

        setupConnection();
        setupSettings();
        buildBindings();
        buildAxes();
        macros = pad.prefs.loadMacros();
        buildMacros();

        findViewById(R.id.btn_add_macro).setOnClickListener(v -> editMacro(-1));

        if (prefs.autoconnect() && !pad.sender.isRunning() && !prefs.getIp().trim().isEmpty()) {
            pad.connect(prefs.getIp().trim());
        }
    }

    @Override protected void onResume() {
        super.onResume();
        ui.post(tick);
    }

    @Override protected void onPause() {
        ui.removeCallbacks(tick);
        pad.onPause();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (isFinishing()) pad.disconnect();
        super.onDestroy();
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            refreshLive();
            ui.postDelayed(this, 50);
        }
    };

    // ---------- eventos do controle ----------
    private static boolean isGamepad(KeyEvent e) {
        return (e.getSource() & (InputDevice.SOURCE_GAMEPAD | InputDevice.SOURCE_JOYSTICK | InputDevice.SOURCE_DPAD)) != 0;
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (powerOverlay != null && e.getKeyCode() == KeyEvent.KEYCODE_BACK && !isGamepad(e)) {
            if (e.getAction() == KeyEvent.ACTION_UP) exitPowerSave();
            return true;
        }
        if (pad.handleKey(e)) return true;
        if (prefs.noDefault() && isGamepad(e)) return true;
        return super.dispatchKeyEvent(e);
    }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent e) {
        if (pad.handleMotion(e)) return true;
        return super.dispatchGenericMotionEvent(e);
    }

    // ---------- conexão ----------
    private void setupConnection() {
        ipEdit.setText(prefs.getIp());
        ipEdit.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { prefs.setIp(s.toString().trim()); }
        });
        ipEdit.setOnEditorActionListener((v, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_DONE) { v.clearFocus(); return false; }
            return false;
        });
        btnConnect.setOnClickListener(v -> {
            if (pad.sender.isRunning()) {
                pad.disconnect();
            } else {
                String ip = ipEdit.getText().toString().trim();
                if (ip.isEmpty()) { Toast.makeText(this, R.string.need_ip, Toast.LENGTH_SHORT).show(); return; }
                pad.connect(ip);
            }
        });
    }

    private void refreshLive() {
        padView.update(pad.state.effectiveMask(), pad.state.sticks());

        boolean running = pad.sender.isRunning();
        String err = pad.lastError();
        int color;
        String text;
        if (err != null) { color = UiText.color(this, R.color.danger); text = getString(R.string.status_error, err); }
        else if (running) { color = UiText.color(this, R.color.ok); text = getString(R.string.status_connected, pad.host()); }
        else { color = UiText.color(this, R.color.text_dim); text = getString(R.string.status_disconnected); }
        statusText.setText(text);
        ((GradientDrawable) statusDot.getBackground().mutate()).setColor(color);
        if (ipEdit.isEnabled() == running) {
            ipEdit.setEnabled(!running);
            ipEdit.setAlpha(running ? 0.55f : 1f);
            if (running) {
                ipEdit.clearFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(ipEdit.getWindowToken(), 0);
            }
        }
        btnConnect.setText(running ? R.string.btn_disconnect : R.string.btn_connect);
        btnConnect.setBackgroundResource(running ? R.drawable.btn_danger : R.drawable.btn_primary);
        btnConnect.setTextColor(running ? Color.WHITE : UiText.onAccent(this));

        if (running != keepOn) {
            keepOn = running;
            if (running) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }

        StringBuilder active = new StringBuilder();
        for (int i = 0; i < macros.size() && i < macroTitles.size(); i++) {
            boolean r = pad.engine.isRunning(i);
            macroTitles.get(i).setTextColor(r ? UiText.accent(this) : UiText.color(this, R.color.text));
            if (r) { if (active.length() > 0) active.append(", "); active.append(macros.get(i).name); }
        }
        macroStatus.setText(active.length() > 0 ? getString(R.string.macro_running_hint, active) : getString(R.string.macro_idle_hint));
    }

    // ---------- botões ----------
    private View row(ViewGroup parent, String title, String value, boolean dim) {
        View r = getLayoutInflater().inflate(R.layout.row_item, parent, false);
        ((TextView) r.findViewById(R.id.row_title)).setText(title);
        TextView v = r.findViewById(R.id.row_value);
        v.setText(value != null ? value : getString(R.string.unbound));
        v.setTextColor(value != null && !dim ? UiText.accent(this) : UiText.color(this, R.color.text_dim));
        parent.addView(r);
        return r;
    }

    private void buildBindings() {
        bindingsBox.removeAllViews();
        for (final Key k : Key.values()) {
            View r = row(bindingsBox, UiText.key(this, k), UiText.keyCode(prefs.getKeyCode(k)), false);
            r.setOnClickListener(v -> captureKey(k));
            r.setOnLongClickListener(v -> {
                prefs.setKeyCode(k, 0);
                pad.reload();
                buildBindings();
                return true;
            });
        }
    }

    private void captureKey(final Key k) {
        final String label = UiText.key(this, k);
        new CaptureDialog(this, getString(R.string.capture_button_title, label),
                getString(R.string.capture_button_msg, label), new CaptureDialog.Callback() {
            @Override public boolean onKey(KeyEvent e) {
                int code = e.getKeyCode();
                prefs.setKeyCode(k, code);
                pad.reload();
                buildBindings();
                Toast.makeText(MainActivity.this,
                        getString(R.string.bound_button, label, UiText.keyCode(code)), Toast.LENGTH_SHORT).show();
                return true;
            }
            @Override public boolean onMotion(MotionEvent e) { return false; }
        }).show();
    }

    // ---------- analógicos ----------
    private static final int[] AXIS_NAMES = {R.string.axis_cpad_x, R.string.axis_cpad_y, R.string.axis_cstick_x, R.string.axis_cstick_y};

    private void buildAxes() {
        axesBox.removeAllViews();
        for (int i = 0; i < Prefs.AXES; i++) {
            final int idx = i;
            String name = UiText.axisName(prefs.getAxis(i));
            View r = row(axesBox, getString(AXIS_NAMES[i]), name, false);
            r.setOnClickListener(v -> captureAxis(idx));
            r.setOnLongClickListener(v -> {
                prefs.setAxis(idx, -1, 1);
                pad.reload();
                buildAxes();
                return true;
            });
        }
    }

    private void captureAxis(final int idx) {
        final String label = getString(AXIS_NAMES[idx]);
        final boolean horizontal = idx % 2 == 0;
        new CaptureDialog(this, getString(R.string.capture_axis_title, label),
                getString(horizontal ? R.string.capture_push_right : R.string.capture_push_up), new CaptureDialog.Callback() {
            @Override public boolean onKey(KeyEvent e) { return false; }
            @Override public boolean onMotion(MotionEvent e) {
                InputDevice d = e.getDevice();
                if (d == null) return false;
                int bestAxis = -1;
                float best = 0f, bestV = 0f;
                for (InputDevice.MotionRange r : d.getMotionRanges()) {
                    int ax = r.getAxis();
                    if (ax == MotionEvent.AXIS_HAT_X || ax == MotionEvent.AXIS_HAT_Y
                            || ax == MotionEvent.AXIS_LTRIGGER || ax == MotionEvent.AXIS_RTRIGGER
                            || ax == MotionEvent.AXIS_BRAKE || ax == MotionEvent.AXIS_GAS) continue;
                    float v = e.getAxisValue(ax);
                    if (Math.abs(v) > best) { best = Math.abs(v); bestAxis = ax; bestV = v; }
                }
                if (bestAxis < 0 || best < 0.6f) return false;
                // "direita" e "cima" devem resultar em valor positivo
                prefs.setAxis(idx, bestAxis, bestV > 0 ? 1 : -1);
                pad.reload();
                buildAxes();
                Toast.makeText(MainActivity.this,
                        getString(R.string.bound_axis, label, UiText.axisName(bestAxis)), Toast.LENGTH_SHORT).show();
                return true;
            }
        }).show();
    }

    // ---------- macros ----------
    private String modeLabel(Macro.Mode m) {
        switch (m) {
            case HOLD: return getString(R.string.mode_hold);
            case TOGGLE: return getString(R.string.mode_toggle);
            default: return getString(R.string.mode_once);
        }
    }

    private void buildMacros() {
        macrosBox.removeAllViews();
        macroTitles.clear();
        macroEmpty.setVisibility(macros.isEmpty() ? View.VISIBLE : View.GONE);
        for (int i = 0; i < macros.size(); i++) {
            final int idx = i;
            final Macro m = macros.get(i);
            View r = getLayoutInflater().inflate(R.layout.row_macro, macrosBox, false);
            TextView title = r.findViewById(R.id.macro_title);
            title.setText(m.name + "  ·  " + UiText.key(this, m.trigger) + "  ·  " + modeLabel(m.mode));
            macroTitles.add(title);
            ((TextView) r.findViewById(R.id.macro_sub)).setText(MacroParser.format(m.steps));
            Switch sw = r.findViewById(R.id.macro_switch);
            sw.setChecked(m.enabled);
            sw.setOnCheckedChangeListener((btn, on) -> { m.enabled = on; saveMacros(false); });
            r.setOnClickListener(v -> editMacro(idx));
            macrosBox.addView(r);
        }
    }

    private void saveMacros(boolean rebuild) {
        prefs.saveMacros(macros);
        pad.engine.setMacros(macros);
        if (rebuild) buildMacros();
    }

    private void editMacro(final int idx) {
        if (idx < 0 && macros.size() >= MacroEngine.MAX_MACROS) {
            Toast.makeText(this, R.string.macro_limit, Toast.LENGTH_SHORT).show();
            return;
        }
        final Macro existing = idx >= 0 ? macros.get(idx) : null;
        MacroEditor.show(this, pad, existing, result -> {
            if (result == null) { if (idx >= 0) macros.remove(idx); }
            else if (idx >= 0) macros.set(idx, result);
            else macros.add(result);
            saveMacros(true);
        });
    }

    // ---------- configurações ----------
    private void setupSettings() {
        Switch inX = findViewById(R.id.sw_inv_x), inY = findViewById(R.id.sw_inv_y);
        Switch trig = findViewById(R.id.sw_analog_trig);
        Switch auto = findViewById(R.id.sw_autoconnect), nodef = findViewById(R.id.sw_nodefault);
        inX.setChecked(prefs.invertCsX());
        inY.setChecked(prefs.invertCsY());
        trig.setChecked(prefs.analogTriggers());
        auto.setChecked(prefs.autoconnect());
        nodef.setChecked(prefs.noDefault());
        inX.setOnCheckedChangeListener((b, on) -> { prefs.setInvertCsX(on); pad.reload(); });
        inY.setOnCheckedChangeListener((b, on) -> { prefs.setInvertCsY(on); pad.reload(); });
        trig.setOnCheckedChangeListener((b, on) -> { prefs.setAnalogTriggers(on); pad.reload(); });
        auto.setOnCheckedChangeListener((b, on) -> prefs.setAutoconnect(on));
        nodef.setOnCheckedChangeListener((b, on) -> prefs.setNoDefault(on));

        SeekBar thr = findViewById(R.id.seek_thr), dz = findViewById(R.id.seek_dz);
        thr.setProgress(prefs.triggerThreshold() - 10);
        dz.setProgress(prefs.deadzone());
        txtThr.setText(getString(R.string.set_trigger_threshold, prefs.triggerThreshold()));
        txtDz.setText(getString(R.string.set_deadzone, prefs.deadzone()));
        thr.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override void changed(int p) {
                prefs.setTriggerThreshold(p + 10);
                txtThr.setText(getString(R.string.set_trigger_threshold, p + 10));
                pad.reload();
            }
        });
        dz.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override void changed(int p) {
                prefs.setDeadzone(p);
                txtDz.setText(getString(R.string.set_deadzone, p));
                pad.reload();
            }
        });

        final String[] codes = {"", "en", "pt"};
        String[] names = {getString(R.string.lang_system), getString(R.string.lang_en), getString(R.string.lang_pt)};
        Spinner sp = findViewById(R.id.spin_lang);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        int cur = 0;
        for (int i = 0; i < codes.length; i++) if (codes[i].equals(prefs.lang())) cur = i;
        sp.setSelection(cur, false);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (!codes[pos].equals(prefs.lang())) {
                    prefs.setLang(codes[pos]);
                    recreate();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });

        setupAccent();
        setupSaver();
        findViewById(R.id.btn_power_save).setOnClickListener(v -> enterPowerSave());
        findViewById(R.id.btn_reset).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setMessage(R.string.reset_confirm)
                        .setPositiveButton(R.string.ok, (d, w) -> {
                            prefs.resetBindings();
                            pad.reload();
                            buildBindings();
                            buildAxes();
                            Toast.makeText(this, R.string.reset_done, Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show());
    }

    // ---------- imagem do protetor de tela ----------
    private static final int REQ_SAVER_IMAGE = 41;
    private Bitmap saverBitmap;
    private TextView saverImageValue, txtSaverBright;

    private void setupSaver() {
        saverImageValue = findViewById(R.id.saver_image_value);
        txtSaverBright = findViewById(R.id.txt_saver_bright);
        SeekBar sb = findViewById(R.id.seek_saver_bright);
        sb.setProgress(prefs.saverBrightness() - 5);
        txtSaverBright.setText(getString(R.string.set_saver_brightness, prefs.saverBrightness()));
        sb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override void changed(int p) {
                prefs.setSaverBrightness(p + 5);
                txtSaverBright.setText(getString(R.string.set_saver_brightness, p + 5));
            }
        });
        refreshSaverRow();
        View row = findViewById(R.id.row_saver_image);
        row.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            startActivityForResult(i, REQ_SAVER_IMAGE);
        });
        row.setOnLongClickListener(v -> {
            prefs.setSaverImage("");
            saverBitmap = null;
            refreshSaverRow();
            return true;
        });
    }

    private void refreshSaverRow() {
        saverImageValue.setText(prefs.saverImage().isEmpty() ? R.string.saver_image_none : R.string.saver_image_set);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_SAVER_IMAGE || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        prefs.setSaverImage(uri.toString());
        saverBitmap = null;
        if (loadSaverBitmap() == null) {
            prefs.setSaverImage("");
            Toast.makeText(this, R.string.saver_image_error, Toast.LENGTH_SHORT).show();
        }
        refreshSaverRow();
    }

    /** Carrega a imagem escolhida já reduzida ao tamanho da tela (com correção de rotação EXIF). */
    private Bitmap loadSaverBitmap() {
        if (saverBitmap != null) return saverBitmap;
        String u = prefs.saverImage();
        if (u.isEmpty()) return null;
        try {
            Uri uri = Uri.parse(u);
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            int target = Math.max(dm.widthPixels, dm.heightPixels);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= target) sample *= 2;
            o.inJustDecodeBounds = false;
            o.inSampleSize = sample;
            Bitmap bmp;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                bmp = BitmapFactory.decodeStream(in, null, o);
            }
            if (bmp == null) return null;
            if (android.os.Build.VERSION.SDK_INT >= 24) {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    int ori = new android.media.ExifInterface(in).getAttributeInt(
                            android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL);
                    int deg = ori == android.media.ExifInterface.ORIENTATION_ROTATE_90 ? 90
                            : ori == android.media.ExifInterface.ORIENTATION_ROTATE_180 ? 180
                            : ori == android.media.ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
                    if (deg != 0) {
                        Matrix m = new Matrix();
                        m.postRotate(deg);
                        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
                    }
                } catch (Exception ignored) { }
            }
            saverBitmap = bmp;
            return bmp;
        } catch (Exception e) {
            return null;
        }
    }

    // ---------- cor de destaque ----------
    private void setupAccent() {
        View sw = findViewById(R.id.accent_swatch);
        int cur = Math.max(0, Math.min(prefs.accent(), UiText.ACCENT_SWATCH.length - 1));
        sw.setBackground(circle(cur == 0 ? UiText.accent(this) : UiText.ACCENT_SWATCH[cur], false));
        findViewById(R.id.row_accent).setOnClickListener(v -> chooseAccent());
    }

    private GradientDrawable circle(int color, boolean selected) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        if (selected) g.setStroke(UiText.dp(this, 3), UiText.color(this, R.color.text));
        return g;
    }

    private void chooseAccent() {
        final int cur = prefs.accent();
        android.widget.GridLayout grid = new android.widget.GridLayout(this);
        grid.setColumnCount(5);
        int pad = UiText.dp(this, 16);
        grid.setPadding(pad, pad, pad, pad);
        final AlertDialog[] dlg = new AlertDialog[1];
        // opção 0 = cor padrão do tema
        for (int i = 0; i < UiText.ACCENT_SWATCH.length; i++) {
            final int idx = i;
            View c = new View(this);
            int color = i == 0 ? UiText.color(this, R.color.accent) : UiText.ACCENT_SWATCH[i];
            c.setBackground(circle(color, i == cur));
            android.widget.GridLayout.LayoutParams lp = new android.widget.GridLayout.LayoutParams();
            lp.width = UiText.dp(this, 44);
            lp.height = UiText.dp(this, 44);
            lp.setMargins(UiText.dp(this, 8), UiText.dp(this, 8), UiText.dp(this, 8), UiText.dp(this, 8));
            c.setLayoutParams(lp);
            c.setOnClickListener(v -> {
                prefs.setAccent(idx);
                dlg[0].dismiss();
                recreate();
            });
            grid.addView(c);
        }
        dlg[0] = new AlertDialog.Builder(this).setTitle(R.string.accent_title).setView(grid)
                .setNegativeButton(R.string.cancel, null).create();
        dlg[0].show();
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        abstract void changed(int progress);
        @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) { if (fromUser) changed(p); }
        @Override public void onStartTrackingTouch(SeekBar s) {}
        @Override public void onStopTrackingTouch(SeekBar s) {}
    }

    // ---------- protetor de tela ----------
    private void enterPowerSave() {
        if (powerOverlay != null) return;
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(Color.BLACK);
        Bitmap bmp = loadSaverBitmap();
        if (bmp != null) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(bmp);
            iv.setAlpha(prefs.saverBrightness() / 100f);
            f.addView(iv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        TextView t = new TextView(this);
        t.setText(R.string.power_save_hint);
        t.setTextColor(bmp != null ? 0x55FFFFFF : 0xFF2A2A2A);
        t.setPadding(0, 0, 0, UiText.dp(this, 24));
        t.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        f.addView(t, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        f.setOnClickListener(v -> exitPowerSave());
        ((ViewGroup) getWindow().getDecorView()).addView(f,
                new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        powerOverlay = f;
    }

    private void exitPowerSave() {
        if (powerOverlay == null) return;
        ((ViewGroup) getWindow().getDecorView()).removeView(powerOverlay);
        powerOverlay = null;
    }
}
