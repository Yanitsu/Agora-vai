package Sono.IRDa.core;

/**
 * Botões do 3DS, na MESMA ordem do app original (a ordem define o bit usado no pacote).
 * Bits 0..11 vão para o campo HID; HOME/POWER/ZL/ZR vão para campos extras.
 * {@link #legacy} é o nome antigo usado nas preferências ("kcal_KEY_xxx") para migração.
 */
public enum Key {
    A("KEY_A"), B("KEY_B"), SELECT("KEY_SELECT"), START("KEY_START"),
    DRIGHT("KEY_DRIGHT"), DLEFT("KEY_DLEFT"), DUP("KEY_DUP"), DDOWN("KEY_DDOWN"),
    R("KEY_R"), L("KEY_L"), X("KEY_X"), Y("KEY_Y"),
    HOME("KEY_L3"), POWER("KEY_R3"), ZL("KEY_ZL"), ZR("KEY_ZR");

    public final String legacy;

    Key(String legacy) { this.legacy = legacy; }

    public int bit() { return 1 << ordinal(); }

    public static Key byName(String s) {
        if (s == null) return null;
        String n = s.trim().toUpperCase(java.util.Locale.ROOT);
        switch (n) {
            case "UP": case "DPAD_UP": case "D-UP": return DUP;
            case "DOWN": case "DPAD_DOWN": case "D-DOWN": return DDOWN;
            case "LEFT": case "DPAD_LEFT": case "D-LEFT": return DLEFT;
            case "RIGHT": case "DPAD_RIGHT": case "D-RIGHT": return DRIGHT;
            default:
        }
        for (Key k : values()) if (k.name().equals(n)) return k;
        return null;
    }

    public static Key byLegacy(String s) {
        for (Key k : values()) if (k.legacy.equals(s)) return k;
        return null;
    }
}
