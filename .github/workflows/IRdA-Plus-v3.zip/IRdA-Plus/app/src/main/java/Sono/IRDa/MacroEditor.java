package Sono.IRDa;

import android.app.Activity;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

import Sono.IRDa.core.Key;
import Sono.IRDa.core.Macro;
import Sono.IRDa.core.MacroParser;

/** Editor de macro (criar / editar / excluir / testar). */
final class MacroEditor {
    interface Done {
        /** m == null quando excluída. */
        void onResult(Macro m);
    }

    private MacroEditor() {}

    static void show(final Activity a, final PadController pad, final Macro existing, final Done done) {
        final View v = LayoutInflater.from(a).inflate(R.layout.dialog_macro, null);
        final EditText name = v.findViewById(R.id.macro_name);
        final Spinner trigger = v.findViewById(R.id.macro_trigger);
        final Spinner mode = v.findViewById(R.id.macro_mode);
        final CheckBox pass = v.findViewById(R.id.macro_passthrough);
        final EditText steps = v.findViewById(R.id.macro_steps);

        final Key[] keys = Key.values();
        String[] keyLabels = new String[keys.length];
        for (int i = 0; i < keys.length; i++) keyLabels[i] = UiText.key(a, keys[i]);
        trigger.setAdapter(adapter(a, keyLabels));

        final Macro.Mode[] modes = Macro.Mode.values();
        mode.setAdapter(adapter(a, new String[]{
                a.getString(R.string.mode_once), a.getString(R.string.mode_hold), a.getString(R.string.mode_toggle)}));

        Macro m = existing != null ? existing : new Macro();
        name.setText(m.name);
        trigger.setSelection(m.trigger.ordinal());
        mode.setSelection(m.mode.ordinal());
        pass.setChecked(m.passthrough);
        steps.setText(MacroParser.format(m.steps));
        final boolean enabled = m.enabled;

        final String[] stickTokens = {"CPAD_UP", "CPAD_DOWN", "CPAD_LEFT", "CPAD_RIGHT",
                "CSTICK_UP", "CSTICK_DOWN", "CSTICK_LEFT", "CSTICK_RIGHT"};
        final String[] insertLabels = new String[keys.length + stickTokens.length];
        System.arraycopy(keyLabels, 0, insertLabels, 0, keys.length);
        System.arraycopy(stickTokens, 0, insertLabels, keys.length, stickTokens.length);
        v.findViewById(R.id.macro_insert_key).setOnClickListener(x ->
                new AlertDialog.Builder(a).setItems(insertLabels, (d, which) -> {
                    if (which < keys.length) append(steps, keys[which].name() + ":50");
                    else append(steps, stickTokens[which - keys.length] + ":500");
                }).show());
        v.findViewById(R.id.macro_insert_wait).setOnClickListener(x -> append(steps, "wait:100"));
        v.findViewById(R.id.macro_templates).setOnClickListener(x -> {
            String[] names = {a.getString(R.string.tpl_turbo), a.getString(R.string.tpl_double), a.getString(R.string.tpl_charge)};
            new AlertDialog.Builder(a).setItems(names, (d, which) -> {
                switch (which) {
                    case 0: steps.setText("A:40 wait:40"); mode.setSelection(Macro.Mode.HOLD.ordinal()); break;
                    case 1: steps.setText("A:40 wait:60 A:40"); mode.setSelection(Macro.Mode.ONCE.ordinal()); break;
                    default: steps.setText("ZR+A:300"); mode.setSelection(Macro.Mode.ONCE.ordinal()); break;
                }
                steps.setError(null);
            }).show();
        });
        v.findViewById(R.id.macro_test).setOnClickListener(x -> {
            Macro t = build(a, name, trigger, mode, pass, steps, keys, modes, true, false);
            if (t == null) return;
            if (!pad.sender.isRunning()) Toast.makeText(a, R.string.macro_test_offline, Toast.LENGTH_SHORT).show();
            pad.engine.runTest(t);
        });

        AlertDialog.Builder b = new AlertDialog.Builder(a)
                .setTitle(existing == null ? R.string.macro_new_title : R.string.macro_edit_title)
                .setView(v)
                .setPositiveButton(R.string.macro_save, null)
                .setNegativeButton(R.string.cancel, null);
        if (existing != null) {
            b.setNeutralButton(R.string.macro_delete, (d, w) -> done.onResult(null));
        }
        final AlertDialog dlg = b.create();
        dlg.setOnShowListener(d -> dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(x -> {
            Macro r = build(a, name, trigger, mode, pass, steps, keys, modes, enabled, true);
            if (r == null) return;
            dlg.dismiss();
            done.onResult(r);
        }));
        dlg.show();
    }

    private static Macro build(Activity a, EditText name, Spinner trigger, Spinner mode, CheckBox pass,
                               EditText steps, Key[] keys, Macro.Mode[] modes, boolean enabled, boolean needName) {
        List<Macro.Step> parsed;
        try {
            parsed = MacroParser.parse(steps.getText().toString());
        } catch (MacroParser.ParseException e) {
            steps.setError(a.getString(R.string.macro_error_token, e.token));
            steps.requestFocus();
            return null;
        }
        if (parsed.isEmpty()) {
            steps.setError(a.getString(R.string.macro_error_empty));
            steps.requestFocus();
            return null;
        }
        Macro m = new Macro();
        m.trigger = keys[trigger.getSelectedItemPosition()];
        m.mode = modes[mode.getSelectedItemPosition()];
        m.passthrough = pass.isChecked();
        m.enabled = enabled;
        m.steps = parsed;
        String n = name.getText().toString().trim();
        m.name = n.isEmpty() ? a.getString(R.string.macro_unnamed, UiText.key(a, m.trigger)) : n;
        return m;
    }

    private static void append(EditText e, String token) {
        String cur = e.getText().toString();
        String sep = cur.isEmpty() || cur.endsWith(" ") || cur.endsWith("\n") ? "" : " ";
        e.setText(cur + sep + token + " ");
        e.setSelection(e.getText().length());
        e.setError(null);
    }

    private static ArrayAdapter<String> adapter(Activity a, String[] items) {
        ArrayAdapter<String> ad = new ArrayAdapter<>(a, android.R.layout.simple_spinner_item, items);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return ad;
    }
}
