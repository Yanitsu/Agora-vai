package Sono.IRDa.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Executa macros disparadas por botões (inclusive ZL/ZR).
 * Cada macro em execução usa uma thread própria e um "owner" no {@link InputState}.
 */
public final class MacroEngine implements InputState.KeyListener {
    private static final int TEST_OWNER = InputState.MAX_OWNERS - 1;
    public static final int MAX_MACROS = InputState.MAX_OWNERS - 1;

    private final InputState state;
    private final Object lock = new Object();
    private List<Macro> macros = new ArrayList<>();
    private final Run[] runs = new Run[InputState.MAX_OWNERS];

    public MacroEngine(InputState state) {
        this.state = state;
        state.setKeyListener(this);
    }

    /** Substitui a lista de macros (para tudo que estiver rodando). */
    public void setMacros(List<Macro> list) {
        synchronized (lock) {
            stopAllLocked();
            macros = new ArrayList<>();
            int suppressed = 0;
            for (Macro m : list) {
                if (macros.size() >= MAX_MACROS) break;
                Macro c = m.copy();
                macros.add(c);
                if (c.enabled && !c.passthrough && !c.steps.isEmpty()) suppressed |= c.trigger.bit();
            }
            state.setSuppressed(suppressed);
        }
    }

    @Override
    public void onPhysicalKey(Key k, boolean down) {
        synchronized (lock) {
            for (int i = 0; i < macros.size(); i++) {
                Macro m = macros.get(i);
                if (!m.enabled || m.steps.isEmpty() || m.trigger != k) continue;
                Run r = runs[i];
                switch (m.mode) {
                    case ONCE:
                        if (down && r == null) start(i, m, false);
                        break;
                    case HOLD:
                        if (down && r == null) start(i, m, true);
                        else if (!down && r != null) stop(i);
                        break;
                    case TOGGLE:
                        if (down) { if (r == null) start(i, m, true); else stop(i); }
                        break;
                }
            }
        }
    }

    /** Executa a macro uma vez, imediatamente (botão "Testar" do editor). */
    public void runTest(Macro m) {
        synchronized (lock) {
            stop(TEST_OWNER);
            if (!m.steps.isEmpty()) start(TEST_OWNER, m.copy(), false);
        }
    }

    public void stopAll() { synchronized (lock) { stopAllLocked(); } }

    public boolean isRunning(int index) {
        synchronized (lock) { return index >= 0 && index < runs.length && runs[index] != null; }
    }

    public boolean anyRunning() {
        synchronized (lock) { for (Run r : runs) if (r != null) return true; return false; }
    }

    // ---- interno (chamar com lock) ----

    private void stopAllLocked() { for (int i = 0; i < runs.length; i++) stop(i); }

    private void start(int owner, Macro m, boolean loop) {
        Run r = new Run(owner, new ArrayList<>(m.steps), loop);
        runs[owner] = r;
        r.thread.start();
    }

    private void stop(int owner) {
        Run r = runs[owner];
        if (r == null) return;
        r.cancel = true;
        r.thread.interrupt();
        runs[owner] = null;
        state.setOwnerMask(owner, 0);
        state.setOwnerSticks(owner, null);
    }

    private final class Run implements Runnable {
        final int owner;
        final List<Macro.Step> steps;
        final boolean loop;
        final Thread thread;
        volatile boolean cancel;

        Run(int owner, List<Macro.Step> steps, boolean loop) {
            this.owner = owner; this.steps = steps; this.loop = loop;
            thread = new Thread(this, "irda-macro-" + owner);
            thread.setDaemon(true);
        }

        private void apply(Macro.Step st) {
            synchronized (lock) {
                if (cancel) return;
                state.setOwnerMask(owner, st == null ? 0 : st.mask);
                state.setOwnerSticks(owner, st == null ? null : st.sticks);
            }
        }

        @Override public void run() {
            try {
                do {
                    int total = 0;
                    for (Macro.Step s : steps) {
                        if (cancel) return;
                        apply(s);
                        if (s.ms > 0) Thread.sleep(s.ms);
                        total += s.ms;
                        apply(null);
                    }
                    if (loop && total < MacroParser.MIN_PRESS_MS) Thread.sleep(MacroParser.MIN_PRESS_MS);
                } while (loop && !cancel);
            } catch (InterruptedException ignored) {
                // cancelado
            } finally {
                synchronized (lock) {
                    if (!cancel) { state.setOwnerMask(owner, 0); state.setOwnerSticks(owner, null); }
                    if (runs[owner] == this) runs[owner] = null;
                }
            }
        }
    }
}
