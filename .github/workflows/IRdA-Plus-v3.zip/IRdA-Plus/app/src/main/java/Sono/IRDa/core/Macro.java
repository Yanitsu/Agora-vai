package Sono.IRDa.core;

import java.util.ArrayList;
import java.util.List;

/** Uma macro: quando {@link #trigger} é pressionado, executa {@link #steps}. */
public final class Macro {
    public enum Mode {
        /** Executa a sequência uma vez a cada toque. */
        ONCE,
        /** Repete a sequência enquanto o botão estiver pressionado. */
        HOLD,
        /** Um toque liga (repete), outro toque desliga. */
        TOGGLE
    }

    public static final class Step {
        /** Máscara de botões a segurar (0 e sem sticks = apenas esperar). */
        public final int mask;
        public final int ms;
        /** {cpadX, cpadY, cstickX, cstickY} em [-1,1] (direita/cima positivos) ou null. */
        public final float[] sticks;
        public Step(int mask, int ms) { this(mask, ms, null); }
        public Step(int mask, int ms, float[] sticks) {
            this.mask = mask; this.ms = ms; this.sticks = sticks;
        }
        public boolean isWait() { return mask == 0 && sticks == null; }
    }

    public String name = "";
    public Key trigger = Key.ZR;
    public Mode mode = Mode.ONCE;
    /** Se verdadeiro, o botão original também continua indo para o 3DS. */
    public boolean passthrough = false;
    public boolean enabled = true;
    public List<Step> steps = new ArrayList<>();

    public Macro copy() {
        Macro m = new Macro();
        m.name = name; m.trigger = trigger; m.mode = mode;
        m.passthrough = passthrough; m.enabled = enabled;
        m.steps = new ArrayList<>(steps);
        return m;
    }
}
