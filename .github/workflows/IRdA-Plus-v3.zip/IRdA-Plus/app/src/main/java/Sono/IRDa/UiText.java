package Sono.IRDa;

import android.content.Context;
import android.os.Build;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.MotionEvent;

import java.util.Locale;

import Sono.IRDa.core.Key;

/** Utilidades de texto/cor/medidas. */
final class UiText {
    private UiText() {}

    static String key(Context c, Key k) {
        int id = c.getResources().getIdentifier("key_" + k.name().toLowerCase(Locale.ROOT), "string", c.getPackageName());
        return id != 0 ? c.getString(id) : k.name();
    }

    static String keyCode(int code) {
        if (code <= 0) return null;
        return KeyEvent.keyCodeToString(code).replace("KEYCODE_", "");
    }

    static String axisName(int axis) {
        if (axis < 0) return null;
        return MotionEvent.axisToString(axis).replace("AXIS_", "");
    }

    static int color(Context c, int id) {
        if (Build.VERSION.SDK_INT >= 23) return c.getColor(id);
        return c.getResources().getColor(id);
    }

    /** Resolve um atributo de cor do tema atual (accent, accentDark, onAccent...). */
    static int attr(Context c, int attrId) {
        TypedValue tv = new TypedValue();
        c.getTheme().resolveAttribute(attrId, tv, true);
        return tv.data;
    }

    static int accent(Context c) { return attr(c, R.attr.accent); }
    static int onAccent(Context c) { return attr(c, R.attr.onAccent); }

    /** Cores das opções de destaque (0 = padrão do tema). Mesma ordem dos estilos Accent1..8. */
    static final int[] ACCENT_STYLES = {0, R.style.Accent1, R.style.Accent2, R.style.Accent3, R.style.Accent4,
            R.style.Accent5, R.style.Accent6, R.style.Accent7, R.style.Accent8};
    static final int[] ACCENT_SWATCH = {0, 0xFF2F6FEB, 0xFF7E57E8, 0xFFDB3F7C, 0xFFD64545,
            0xFFE8590C, 0xFFB7791F, 0xFF2E9E4F, 0xFF0E8FB0};

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }
}
