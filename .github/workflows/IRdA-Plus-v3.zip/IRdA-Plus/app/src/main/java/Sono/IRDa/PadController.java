package Sono.IRDa;

import android.content.Context;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;

import Sono.IRDa.core.InputState;
import Sono.IRDa.core.Key;
import Sono.IRDa.core.MacroEngine;
import Sono.IRDa.core.UdpSender;

/** Liga o Android (teclas/eixos) ao estado de entrada, às macros e ao envio UDP. */
public final class PadController {
    public final Prefs prefs;
    public final InputState state = new InputState();
    public final MacroEngine engine = new MacroEngine(state);
    public final UdpSender sender = new UdpSender(state);

    private final int[] keyCodes = new int[Key.values().length];
    private final int[] axis = new int[Prefs.AXES];
    private final int[] sign = new int[Prefs.AXES];
    private boolean analogTriggers, invCsX, invCsY;
    private float trigThr = 0.5f, deadzone = 0.12f;
    private boolean zlAxis, zrAxis;

    private volatile String lastError;
    private volatile String host = "";

    public PadController(Context c) {
        prefs = new Prefs(c);
        reload();
        engine.setMacros(prefs.loadMacros());
    }

    /** Recarrega mapeamentos e opções das preferências. */
    public void reload() {
        for (Key k : Key.values()) keyCodes[k.ordinal()] = prefs.getKeyCode(k);
        for (int i = 0; i < Prefs.AXES; i++) { axis[i] = prefs.getAxis(i); sign[i] = prefs.getAxisSign(i); }
        analogTriggers = prefs.analogTriggers();
        trigThr = prefs.triggerThreshold() / 100f;
        deadzone = prefs.deadzone() / 100f;
        invCsX = prefs.invertCsX();
        invCsY = prefs.invertCsY();
    }

    // ---------- entrada ----------
    public boolean handleKey(KeyEvent e) {
        int code = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        boolean handled = false;
        for (Key k : Key.values()) {
            int c = keyCodes[k.ordinal()];
            if (c != 0 && c == code) {
                state.setSource(InputState.SRC_BUTTON, k, down);
                handled = true;
            }
        }
        return handled;
    }

    public boolean handleMotion(MotionEvent e) {
        if ((e.getSource() & InputDevice.SOURCE_CLASS_JOYSTICK) == 0
                || e.getAction() != MotionEvent.ACTION_MOVE) return false;

        float csx = read(e, 2), csy = read(e, 3);
        if (invCsX) csx = -csx;
        if (invCsY) csy = -csy;
        state.setSticks(read(e, 0), read(e, 1), csx, csy);

        float hx = e.getAxisValue(MotionEvent.AXIS_HAT_X);
        float hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y);
        state.setSource(InputState.SRC_AXIS, Key.DLEFT, hx < -0.5f);
        state.setSource(InputState.SRC_AXIS, Key.DRIGHT, hx > 0.5f);
        state.setSource(InputState.SRC_AXIS, Key.DUP, hy < -0.5f);
        state.setSource(InputState.SRC_AXIS, Key.DDOWN, hy > 0.5f);

        if (analogTriggers) {
            float lt = Math.max(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE));
            float rt = Math.max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS));
            zlAxis = hysteresis(zlAxis, lt);
            zrAxis = hysteresis(zrAxis, rt);
        } else {
            zlAxis = false; zrAxis = false;
        }
        state.setSource(InputState.SRC_AXIS, Key.ZL, zlAxis);
        state.setSource(InputState.SRC_AXIS, Key.ZR, zrAxis);
        return true;
    }

    private boolean hysteresis(boolean cur, float v) {
        return cur ? v > trigThr - 0.1f : v >= trigThr;
    }

    private float read(MotionEvent e, int i) {
        int ax = axis[i];
        if (ax < 0) return 0f;
        float v = e.getAxisValue(ax) * sign[i];
        float a = Math.abs(v);
        if (a < deadzone) return 0f;
        float r = Math.min((a - deadzone) / (1f - deadzone), 1f);
        return v < 0 ? -r : r;
    }

    // ---------- conexão ----------
    public void connect(String ip) {
        host = ip;
        lastError = null;
        sender.start(ip, (running, err) -> lastError = err);
    }

    public void disconnect() {
        engine.stopAll();
        sender.stop();
        state.releaseAll();
    }

    public String lastError() { return lastError; }
    public String host() { return host; }

    /** App saiu de foco: o Android deixa de entregar eventos, então solta tudo. */
    public void onPause() {
        engine.stopAll();
        state.releaseAll();
        zlAxis = false; zrAxis = false;
    }
}
