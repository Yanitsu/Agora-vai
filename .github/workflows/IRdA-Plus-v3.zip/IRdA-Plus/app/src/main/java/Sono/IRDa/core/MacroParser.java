package Sono.IRDa.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Sintaxe das macros (texto simples):
 * <pre>
 *   A:50 wait:100 ZL+X:80      # segura A 50ms, espera 100ms, segura ZL+X 80ms
 * </pre>
 * Separadores: espaço, quebra de linha, vírgula ou ponto-e-vírgula. "#" inicia comentário.
 * Tempo: "50", "50ms" ou "0.5s". Espera: "wait" ou "w".
 * Analógicos: CPAD_UP/DOWN/LEFT/RIGHT (Circle Pad) e CSTICK_UP/DOWN/LEFT/RIGHT (C-Stick),
 * combináveis com botões: CPAD_UP+A:500.
 */
public final class MacroParser {
    public static final int DEFAULT_MS = 50;
    public static final int MIN_PRESS_MS = 16;
    public static final int MAX_MS = 600_000;

    public static final class ParseException extends Exception {
        public final String token;
        public ParseException(String msg, String token) { super(msg); this.token = token; }
    }

    private MacroParser() {}

    public static List<Macro.Step> parse(String text) throws ParseException {
        List<Macro.Step> out = new ArrayList<>();
        if (text == null) return out;
        for (String line : text.split("\\r?\\n")) {
            int c = line.indexOf('#');
            if (c >= 0) line = line.substring(0, c);
            for (String tok : line.split("[\\s,;]+")) {
                if (tok.isEmpty()) continue;
                out.add(parseToken(tok));
            }
        }
        return out;
    }

    private static Macro.Step parseToken(String tok) throws ParseException {
        String keys = tok;
        int ms = DEFAULT_MS;
        int i = tok.indexOf(':');
        if (i >= 0) {
            keys = tok.substring(0, i);
            ms = parseTime(tok.substring(i + 1), tok);
        }
        String kl = keys.toLowerCase(Locale.ROOT);
        if (kl.equals("wait") || kl.equals("w")) {
            return new Macro.Step(0, ms);
        }
        int mask = 0;
        float[] sticks = null;
        for (String part : keys.split("\\+")) {
            Key k = Key.byName(part);
            if (k != null) { mask |= k.bit(); continue; }
            int[] sd = stickDir(part);
            if (sd == null) throw new ParseException("unknown key", tok);
            if (sticks == null) sticks = new float[4];
            sticks[sd[0]] = sd[1];
        }
        if (mask == 0 && sticks == null) throw new ParseException("empty", tok);
        return new Macro.Step(mask, Math.max(ms, MIN_PRESS_MS), sticks);
    }

    private static final String[] STICK_NAMES = {"CPAD", "CSTICK"};
    private static final String[] DIR_NAMES = {"RIGHT", "LEFT", "UP", "DOWN"};

    /** @return {índice no vetor de sticks, +1/-1} ou null. */
    private static int[] stickDir(String part) {
        String n = part.trim().toUpperCase(Locale.ROOT).replace("-", "_");
        if (n.startsWith("STICK_")) n = "CPAD_" + n.substring(6);
        for (int si = 0; si < 2; si++) {
            for (String d : DIR_NAMES) {
                if (!n.equals(STICK_NAMES[si] + "_" + d)) continue;
                boolean horiz = d.equals("RIGHT") || d.equals("LEFT");
                int idx = si * 2 + (horiz ? 0 : 1);
                int sign = (d.equals("RIGHT") || d.equals("UP")) ? 1 : -1;
                return new int[]{idx, sign};
            }
        }
        return null;
    }

    private static int parseTime(String s, String tok) throws ParseException {
        String t = s.trim().toLowerCase(Locale.ROOT);
        try {
            double v;
            if (t.endsWith("ms")) v = Double.parseDouble(t.substring(0, t.length() - 2));
            else if (t.endsWith("s")) v = Double.parseDouble(t.substring(0, t.length() - 1)) * 1000.0;
            else v = Double.parseDouble(t);
            if (v < 0 || v > MAX_MS || Double.isNaN(v)) throw new ParseException("bad time", tok);
            return (int) Math.round(v);
        } catch (NumberFormatException e) {
            throw new ParseException("bad time", tok);
        }
    }

    public static String format(List<Macro.Step> steps) {
        StringBuilder sb = new StringBuilder();
        for (Macro.Step s : steps) {
            if (sb.length() > 0) sb.append(' ');
            if (s.isWait()) { sb.append("wait"); }
            else {
                boolean first = true;
                for (Key k : Key.values()) {
                    if ((s.mask & k.bit()) == 0) continue;
                    if (!first) sb.append('+');
                    sb.append(k.name());
                    first = false;
                }
                if (s.sticks != null) {
                    for (int i = 0; i < 4; i++) {
                        if (s.sticks[i] == 0f) continue;
                        if (!first) sb.append('+');
                        boolean horiz = i % 2 == 0;
                        String d = horiz ? (s.sticks[i] > 0 ? "RIGHT" : "LEFT") : (s.sticks[i] > 0 ? "UP" : "DOWN");
                        sb.append(STICK_NAMES[i / 2]).append('_').append(d);
                        first = false;
                    }
                }
            }
            sb.append(':').append(s.ms);
        }
        return sb.toString();
    }
}
