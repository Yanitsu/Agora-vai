package Sono.IRDa.core;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/** Envia o estado ao 3DS por UDP: imediatamente a cada mudança + keep-alive periódico. */
public final class UdpSender {
    public interface Listener {
        /** Chamado em thread de rede. error == null quando tudo ok. */
        void onStatus(boolean running, String error);
    }

    public static final int KEEPALIVE_MS = 100;
    private static final long MIN_GAP_NS = 4_000_000L; // máx. ~250 pacotes/s

    private final InputState state;
    private final Object mutex = new Object();
    private volatile boolean dirty;
    private Thread thread;

    public UdpSender(InputState state) {
        this.state = state;
        state.setChangeListener(this::poke);
    }

    public void poke() {
        dirty = true;
        synchronized (mutex) { mutex.notifyAll(); }
    }

    public synchronized boolean isRunning() { return thread != null && thread.isAlive(); }

    public synchronized void start(final String host, final Listener l) {
        stop();
        thread = new Thread(() -> loop(host, l), "irda-net");
        thread.setDaemon(true);
        thread.start();
    }

    public synchronized void stop() {
        Thread t = thread;
        thread = null;
        if (t == null) return;
        t.interrupt();
        try { t.join(1500); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    private void loop(String host, Listener l) {
        DatagramSocket sock = null;
        DatagramPacket pkt = null;
        byte[] buf = new byte[PacketBuilder.SIZE];
        try {
            InetAddress addr = InetAddress.getByName(host);
            pkt = new DatagramPacket(buf, buf.length, addr, PacketBuilder.PORT);
            sock = new DatagramSocket();
            if (l != null) l.onStatus(true, null);
            long last = 0;
            while (!Thread.currentThread().isInterrupted()) {
                dirty = false;
                state.pack(buf);
                try {
                    sock.send(pkt);
                    last = System.nanoTime();
                } catch (IOException e) {
                    if (l != null) l.onStatus(true, e.getMessage());
                    Thread.sleep(500);
                    continue;
                }
                synchronized (mutex) {
                    if (!dirty) mutex.wait(KEEPALIVE_MS);
                }
                long gap = MIN_GAP_NS - (System.nanoTime() - last);
                if (gap > 0) Thread.sleep(gap / 1_000_000L, (int) (gap % 1_000_000L));
            }
        } catch (InterruptedException ignored) {
            // parada normal
        } catch (IOException e) {
            if (l != null) l.onStatus(false, String.valueOf(e.getMessage()));
            return;
        } finally {
            // solta tudo no 3DS para não ficar com botão preso
            if (sock != null && pkt != null) {
                try {
                    PacketBuilder.build(buf, 0, 0, 0, 0, 0);
                    sock.send(pkt);
                } catch (IOException ignored) { }
                sock.close();
            }
        }
        if (l != null) l.onStatus(false, null);
    }
}
