import Sono.IRDa.core.*;
import java.net.*;
import java.util.*;

public class CoreTest {
    static int fails = 0;
    static void check(boolean c, String m) { if (!c) { fails++; System.out.println("FAIL: " + m); } else System.out.println("ok:   " + m); }
    static String hex(byte[] b) { StringBuilder s = new StringBuilder(); for (byte x : b) s.append(String.format("%02x", x)); return s.toString(); }

    public static void main(String[] a) throws Exception {
        // --- pacote ---
        byte[] b = new byte[20];
        PacketBuilder.build(b, 0, 0, 0, 0, 0);
        check(hex(b).equals("ff0f0000" + "00000002" + "00088000" + "81008080" + "00000000"), "pacote ocioso " + hex(b));
        PacketBuilder.build(b, Key.A.bit() | Key.Y.bit(), 0, 0, 0, 0);
        check((b[0] & 0xFF) == 0xFE && (b[1] & 0xFF) == 0x07, "A e Y pressionados -> bits 0 e 11 em zero");
        PacketBuilder.build(b, Key.ZL.bit(), 0, 0, 0, 0);
        check(b[13] == 4, "ZL = 0x04 no byte 13");
        PacketBuilder.build(b, Key.ZR.bit(), 0, 0, 0, 0);
        check(b[13] == 2, "ZR = 0x02 no byte 13");
        PacketBuilder.build(b, Key.ZR.bit() | Key.ZL.bit(), 0, 0, 0, 0);
        check(b[13] == 6, "ZL+ZR = 0x06");
        check((b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0x0F, "ZL/ZR nao afetam HID");
        PacketBuilder.build(b, Key.HOME.bit(), 0, 0, 0, 0);
        check(b[16] == 1, "HOME = bit0 do byte 16");
        PacketBuilder.build(b, Key.POWER.bit(), 0, 0, 0, 0);
        check(b[16] == 2, "POWER = bit1 do byte 16");
        PacketBuilder.build(b, 0, 1, 1, 0, 0);
        int cp = (b[8] & 0xFF) | ((b[9] & 0xFF) << 8) | ((b[10] & 0xFF) << 16);
        check((cp & 0xFFF) == 0xFFF && ((cp >> 12) & 0xFFF) == 0xFFF, "circle pad no canto = 0xFFF/0xFFF (" + Integer.toHexString(cp) + ")");
        PacketBuilder.build(b, 0, 0, 0, 0, 1); // C-stick pra cima
        check((b[14] & 0xFF) == 217 && (b[15] & 0xFF) == 217, "C-stick cima -> 217/217 (" + (b[14] & 0xFF) + "/" + (b[15] & 0xFF) + ")");
        PacketBuilder.build(b, 0, 0, 0, 1, 0); // C-stick direita
        check((b[14] & 0xFF) == 217 && (b[15] & 0xFF) == 38, "C-stick direita -> 217/38 (" + (b[14] & 0xFF) + "/" + (b[15] & 0xFF) + ")");

        // --- parser ---
        List<Macro.Step> st = MacroParser.parse("A:50 wait:100 ZL+X:80ms # comentario\n w:0.5s, B");
        check(st.size() == 5, "parser: 5 passos");
        check(st.get(0).mask == Key.A.bit() && st.get(0).ms == 50, "A:50");
        check(st.get(1).mask == 0 && st.get(1).ms == 100, "wait:100");
        check(st.get(2).mask == (Key.ZL.bit() | Key.X.bit()) && st.get(2).ms == 80, "ZL+X:80ms");
        check(st.get(3).mask == 0 && st.get(3).ms == 500, "w:0.5s");
        check(st.get(4).mask == Key.B.bit() && st.get(4).ms == 50, "B (padrao 50ms)");
        check(MacroParser.parse("A:1").get(0).ms == MacroParser.MIN_PRESS_MS, "tempo minimo de toque");
        check(MacroParser.format(MacroParser.parse("zr+a:30 up:20 wait")).equals("A+ZR:30 DUP:20 wait:50"), "format/roundtrip: " + MacroParser.format(MacroParser.parse("zr+a:30 up:20 wait")));
        try { MacroParser.parse("A:50 Q:10"); check(false, "token invalido deveria falhar"); }
        catch (MacroParser.ParseException e) { check(e.token.equals("Q:10"), "erro aponta token Q:10"); }
        try { MacroParser.parse("A:abc"); check(false, "tempo invalido"); }
        catch (MacroParser.ParseException e) { check(true, "tempo invalido rejeitado"); }

        // --- engine: ZR ONCE ---
        InputState state = new InputState();
        MacroEngine eng = new MacroEngine(state);
        Macro m = new Macro(); m.name = "combo"; m.trigger = Key.ZR; m.mode = Macro.Mode.ONCE;
        m.steps = MacroParser.parse("A:60 wait:40 B:60");
        eng.setMacros(Arrays.asList(m));
        state.setSource(InputState.SRC_BUTTON, Key.ZR, true);
        check((state.effectiveMask() & Key.ZR.bit()) == 0, "ZR fisico suprimido (macro ativa)");
        Thread.sleep(30);
        check((state.effectiveMask() & Key.A.bit()) != 0, "macro: A segurado em t=30ms");
        Thread.sleep(60);
        check(state.effectiveMask() == 0, "macro: soltou no wait (t=90ms)");
        Thread.sleep(40);
        check((state.effectiveMask() & Key.B.bit()) != 0, "macro: B segurado (t=130ms)");
        Thread.sleep(100);
        check(state.effectiveMask() == 0, "macro: terminou limpo");
        state.setSource(InputState.SRC_BUTTON, Key.ZR, false);
        check(!eng.anyRunning(), "nenhuma macro rodando");

        // --- engine: ZL HOLD (turbo) ---
        Macro t = new Macro(); t.trigger = Key.ZL; t.mode = Macro.Mode.HOLD;
        t.steps = MacroParser.parse("A:30 wait:30");
        eng.setMacros(Arrays.asList(t));
        state.setSource(InputState.SRC_BUTTON, Key.ZL, true);
        int on = 0, off = 0;
        for (int i = 0; i < 40; i++) { Thread.sleep(5); if ((state.effectiveMask() & Key.A.bit()) != 0) on++; else off++; }
        check(on > 5 && off > 5, "turbo alterna A (on=" + on + " off=" + off + ")");
        state.setSource(InputState.SRC_BUTTON, Key.ZL, false);
        Thread.sleep(20);
        check(state.effectiveMask() == 0 && !eng.anyRunning(), "soltar ZL para o turbo e limpa");

        // --- engine: TOGGLE + passthrough ---
        Macro g = new Macro(); g.trigger = Key.L; g.mode = Macro.Mode.TOGGLE; g.passthrough = true;
        g.steps = MacroParser.parse("X:30 wait:30");
        eng.setMacros(Arrays.asList(g));
        state.setSource(InputState.SRC_BUTTON, Key.L, true);
        check((state.effectiveMask() & Key.L.bit()) != 0, "passthrough: L continua indo");
        state.setSource(InputState.SRC_BUTTON, Key.L, false);
        Thread.sleep(80);
        check(eng.anyRunning(), "toggle ligado continua apos soltar");
        state.setSource(InputState.SRC_BUTTON, Key.L, true);
        state.setSource(InputState.SRC_BUTTON, Key.L, false);
        Thread.sleep(40);
        check(!eng.anyRunning() && state.effectiveMask() == 0, "toggle desligado");

        // --- duas fontes (botao + gatilho analogico) na mesma tecla ---
        eng.setMacros(new ArrayList<Macro>());
        state.setSource(InputState.SRC_BUTTON, Key.ZL, true);
        state.setSource(InputState.SRC_AXIS, Key.ZL, true);
        state.setSource(InputState.SRC_BUTTON, Key.ZL, false);
        check((state.effectiveMask() & Key.ZL.bit()) != 0, "ZL segue pressionado pela outra fonte");
        state.setSource(InputState.SRC_AXIS, Key.ZL, false);
        check(state.effectiveMask() == 0, "ZL solto");

        // --- analogicos em macro ---
        List<Macro.Step> sp = MacroParser.parse("CPAD_UP:300 wait:50 CSTICK_LEFT+A:100 stick_down:40");
        check(sp.size() == 4 && sp.get(0).sticks[1] == 1f && sp.get(0).mask == 0, "parser: CPAD_UP -> cpadY=+1");
        check(sp.get(2).sticks[2] == -1f && sp.get(2).mask == Key.A.bit(), "parser: CSTICK_LEFT+A");
        check(sp.get(3).sticks[1] == -1f, "parser: stick_down = CPAD_DOWN");
        check(MacroParser.format(sp).equals("CPAD_UP:300 wait:50 A+CSTICK_LEFT:100 CPAD_DOWN:40"), "format: " + MacroParser.format(sp));
        Macro sm = new Macro(); sm.trigger = Key.ZL; sm.mode = Macro.Mode.ONCE;
        sm.steps = MacroParser.parse("CPAD_UP:120 wait:50");
        eng.setMacros(Arrays.asList(sm));
        state.setSource(InputState.SRC_BUTTON, Key.ZL, true);
        Thread.sleep(40);
        check(state.sticks()[1] == 1f, "macro move o Circle Pad para cima");
        byte[] pk = new byte[20]; state.pack(pk);
        int cpy2 = (((pk[10] & 0xFF) << 16 | (pk[9] & 0xFF) << 8 | (pk[8] & 0xFF)) >> 12) & 0xFFF;
        check(cpy2 == 2048 + 2047, "pacote: cpad Y = 0xFFF (cima)");
        Thread.sleep(200);
        check(state.sticks()[1] == 0f, "analogico volta ao centro depois");
        state.setSource(InputState.SRC_BUTTON, Key.ZL, false);
        eng.setMacros(new ArrayList<Macro>());

        // --- UDP de verdade (loopback) ---
        DatagramSocket srv = new DatagramSocket(PacketBuilder.PORT, InetAddress.getByName("127.0.0.1"));
        srv.setSoTimeout(1000);
        UdpSender snd = new UdpSender(state);
        snd.start("127.0.0.1", null);
        byte[] rx = new byte[64];
        DatagramPacket p = new DatagramPacket(rx, rx.length);
        srv.receive(p);
        check(p.getLength() == 20, "UDP: pacote de 20 bytes recebido na porta 4950");
        state.setSource(InputState.SRC_BUTTON, Key.ZR, true);
        boolean seen = false;
        for (int i = 0; i < 20 && !seen; i++) { srv.receive(p); seen = (rx[13] & 2) != 0; }
        check(seen, "UDP: ZR chega ao 3DS (byte13 bit1)");
        snd.stop();
        // ultimo pacote deve ser 'tudo solto'
        byte[] lastp = null;
        try { while (true) { srv.receive(p); lastp = Arrays.copyOf(rx, 20); } } catch (SocketTimeoutException e) { }
        check(lastp != null && lastp[13] == 0 && (lastp[0] & 0xFF) == 0xFF, "UDP: pacote final solta tudo");
        srv.close();

        System.out.println(fails == 0 ? "\nTODOS OS TESTES PASSARAM" : "\nFALHAS: " + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
