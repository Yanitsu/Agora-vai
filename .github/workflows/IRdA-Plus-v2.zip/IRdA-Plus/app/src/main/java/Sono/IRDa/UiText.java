package Sono.IRDa;

import android.content.Context;
import android.os.Build;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.MotionEvent;

import java.util.Locale;

import Sono.IRDa.core.Key;

/** Utilidades de texto/cor/medidas. */
final class UiText {
    private UiText() {}

    static String key(Context c, Key k) {
        int id = c.getResources().getIdentifier("key_" + k.name().toLowerCase(Locale.ROOT), "string", c.getPackageName());
        return id != 0 ? c.getString(id) : k.name();
    }

    static String keyCode(int code) {
        if (code <= 0) return null;
        return KeyEvent.keyCodeToString(code).replace("KEYCODE_", "");
    }

    static String axisName(int axis) {
        if (axis < 0) return null;
        return MotionEvent.axisToString(axis).replace("AXIS_", "");
    }

    static int color(Context c, int id) {
        if (Build.VERSION.SDK_INT >= 23) return c.getColor(id);
        return c.getResources().getColor(id);
    }

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }
}
