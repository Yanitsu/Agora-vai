package Sono.IRDa;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import Sono.IRDa.core.Key;

/** Desenho do controle do 3DS mostrando, ao vivo, o que está sendo enviado. */
public final class PadView extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private int cIdle, cFace, cOn, cOnText, cText;
    private int mask;
    private float cpx, cpy, csx, csy;

    public PadView(Context c) { super(c); init(c); }
    public PadView(Context c, AttributeSet a) { super(c, a); init(c); }

    private void init(Context c) {
        cIdle = UiText.color(c, R.color.pad_idle);
        cFace = UiText.color(c, R.color.pad_face);
        cOn = UiText.color(c, R.color.accent);
        cOnText = UiText.color(c, R.color.on_accent);
        cText = UiText.color(c, R.color.text_dim);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(UiText.dp(c, 1.5f));
        text.setTextAlign(Paint.Align.CENTER);
        text.setFakeBoldText(true);
    }

    public void update(int mask, float[] sticks) {
        if (this.mask == mask && cpx == sticks[0] && cpy == sticks[1] && csx == sticks[2] && csy == sticks[3]) return;
        this.mask = mask;
        cpx = sticks[0]; cpy = sticks[1]; csx = sticks[2]; csy = sticks[3];
        invalidate();
    }

    @Override protected void onMeasure(int w, int h) {
        int width = MeasureSpec.getSize(w);
        setMeasuredDimension(width, Math.round(width * 0.55f));
    }

    private boolean on(Key k) { return (mask & k.bit()) != 0; }

    private void pill(Canvas c, float l, float t, float r, float b, boolean pressed, String label) {
        rect.set(l, t, r, b);
        float rad = (b - t) / 2f;
        fill.setColor(pressed ? cOn : cFace);
        c.drawRoundRect(rect, rad, rad, fill);
        line.setColor(pressed ? cOn : cIdle);
        c.drawRoundRect(rect, rad, rad, line);
        text.setColor(pressed ? cOnText : cText);
        text.setTextSize((b - t) * 0.5f);
        c.drawText(label, (l + r) / 2f, (t + b) / 2f + text.getTextSize() * 0.35f, text);
    }

    private void round(Canvas c, float x, float y, float r, boolean pressed, String label) {
        fill.setColor(pressed ? cOn : cFace);
        c.drawCircle(x, y, r, fill);
        line.setColor(pressed ? cOn : cIdle);
        c.drawCircle(x, y, r, line);
        text.setColor(pressed ? cOnText : cText);
        text.setTextSize(r * 1.0f);
        c.drawText(label, x, y + text.getTextSize() * 0.35f, text);
    }

    private void stick(Canvas c, float x, float y, float r, float vx, float vy) {
        fill.setColor(cFace);
        c.drawCircle(x, y, r, fill);
        line.setColor(cIdle);
        c.drawCircle(x, y, r, line);
        boolean moved = vx != 0 || vy != 0;
        fill.setColor(moved ? cOn : cIdle);
        c.drawCircle(x + vx * r * 0.7f, y - vy * r * 0.7f, r * 0.38f, fill);
    }

    private void dpadArm(Canvas c, float x, float y, float w, float h, boolean pressed) {
        rect.set(x - w / 2, y - h / 2, x + w / 2, y + h / 2);
        fill.setColor(pressed ? cOn : cFace);
        c.drawRoundRect(rect, w * 0.2f, w * 0.2f, fill);
        line.setColor(pressed ? cOn : cIdle);
        c.drawRoundRect(rect, w * 0.2f, w * 0.2f, line);
    }

    @Override protected void onDraw(Canvas c) {
        float W = getWidth(), H = getHeight();
        fill.setStyle(Paint.Style.FILL);

        // gatilhos / ombros
        float sy1 = H * 0.02f, sy2 = H * 0.17f;
        pill(c, W * 0.03f, sy1, W * 0.21f, sy2, on(Key.ZL), "ZL");
        pill(c, W * 0.23f, sy1, W * 0.41f, sy2, on(Key.L), "L");
        pill(c, W * 0.59f, sy1, W * 0.77f, sy2, on(Key.R), "R");
        pill(c, W * 0.79f, sy1, W * 0.97f, sy2, on(Key.ZR), "ZR");

        // Circle Pad e D-Pad (esquerda)
        stick(c, W * 0.17f, H * 0.40f, W * 0.085f, cpx, cpy);
        float dx = W * 0.17f, dy = H * 0.81f, arm = W * 0.05f, len = W * 0.075f;
        dpadArm(c, dx, dy - arm, arm, len, on(Key.DUP));
        dpadArm(c, dx, dy + arm, arm, len, on(Key.DDOWN));
        dpadArm(c, dx - arm, dy, len, arm, on(Key.DLEFT));
        dpadArm(c, dx + arm, dy, len, arm, on(Key.DRIGHT));

        // ABXY e C-Stick (direita)
        float bx = W * 0.83f, by = H * 0.38f, o = W * 0.06f, r = W * 0.036f;
        round(c, bx, by - o, r, on(Key.X), "X");
        round(c, bx, by + o, r, on(Key.B), "B");
        round(c, bx - o, by, r, on(Key.Y), "Y");
        round(c, bx + o, by, r, on(Key.A), "A");
        stick(c, W * 0.83f, H * 0.80f, W * 0.055f, csx, csy);

        // centro
        pill(c, W * 0.34f, H * 0.62f, W * 0.48f, H * 0.72f, on(Key.SELECT), "SEL");
        pill(c, W * 0.52f, H * 0.62f, W * 0.66f, H * 0.72f, on(Key.START), "STA");
        round(c, W * 0.50f, H * 0.86f, W * 0.04f, on(Key.HOME), "H");
        round(c, W * 0.50f, H * 0.42f, W * 0.03f, on(Key.POWER), "P");
    }
}
